#!/usr/bin/env python3
# tao_anh.py - Tao anh mau de thuc hanh
import numpy as np
from PIL import Image

img = np.zeros((512, 512), dtype=np.uint8)
for i in range(512):
    for j in range(512):
        img[i,j] = int(128 + 40*np.sin(2*np.pi*i/64)*np.cos(2*np.pi*j/64))
img[100:200, 100:200] = 200
img[250:380, 250:380] = 180
Image.fromarray(img).save("cover.png")
print("Da tao anh: cover.png (512x512)")
