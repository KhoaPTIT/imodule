#!/bin/bash
cd $HOME
python3 tao_anh.py
echo "================================================="
echo " BAI LAB: PHONG THU CHONG TAN CONG HINH HOC"
echo " Doc file instructions.txt de bat dau"
echo "================================================="
