#!/usr/bin/env python3
# defense.py 
#
# BAI TAP: Hoan thanh 3 ham duoi day de xay dung co che phong thu
# chong tan cong hinh hoc vao giau tin DCT.
#
# Sau khi hoan thanh, chay:
#   python3 defense.py embed cover.png "SecretMsg" stego_def.png
#   python3 defense.py extract stego_def.png
#   
import numpy as np
from scipy.fft import dctn, idctn
from PIL import Image
import cv2
import sys

# PHAN 1: MA SUA LOI (Error Correction)
# Ky thuat: Ma lap (Repetition Code)
# Moi bit duoc lap lai REPEAT lan. Khi giai ma, dung bau chon da so.

REPEAT = 5  # Moi bit lap 5 lan

def repetition_encode(bits):
    """Ma hoa: moi bit lap lai REPEAT lan.
    Vi du: [1, 0] voi REPEAT=3 -> [1,1,1, 0,0,0]
    """
    encoded = []
    for bit in bits:
        # TODO: Them bit nay REPEAT lan vao encoded
        # Goi y: dung list * hoac vong lap
        pass  
    return encoded

def repetition_decode(bits):
    """Giai ma: voi moi nhom REPEAT bit, chon bit xuat hien nhieu hon.
    Vi du: [1,1,0, 0,1,0] voi REPEAT=3 -> [1, 0]
    """
    decoded = []
    for i in range(0, len(bits), REPEAT):
        chunk = bits[i:i+REPEAT]
        if len(chunk) < REPEAT:
            break
        # TODO: Dem so bit 1 trong chunk
        # Neu so bit 1 > REPEAT/2 thi ket qua la 1, nguoc lai la 0
        # Goi y: dung sum(chunk) de dem so bit 1
        pass 
    return decoded


# PHAN 2: SPREAD SPECTRUM EMBEDDING 
# Ky thuat: Trai moi bit len nhieu he so DCT thay vi 1 he so
# Dung chuoi gia ngau nhien PN (Pseudo-Noise)

# Vi tri tan so trung binh trong khoi 8x8
MID_FREQ = [(1,2),(2,1),(3,0),(0,3),(1,3),(2,2),(3,1),(4,0)]

def make_pn(seed, length=8):
    """Tao chuoi PN tu seed"""
    np.random.seed(seed)
    return np.random.choice([-1, 1], size=length)

def ss_embed_block(dct_block, bit, pn, alpha=15):
    """Nhung 1 bit vao khoi DCT bang Spread Spectrum.
    - bit=1: cong alpha*pn vao cac he so tan so trung binh
    - bit=0: tru alpha*pn khoi cac he so tan so trung binh
    """
    out = dct_block.copy()
    val = 1 if bit == 1 else -1
    for k in range(len(pn)):
        r, c = MID_FREQ[k]
        # TODO: Cong alpha * val * pn[k] vao he so out[r, c]
        pass  
    return out

def ss_extract_block(dct_block, pn):
    """Trich xuat 1 bit tu khoi DCT bang tuong quan voi chuoi PN.
    Tinh tong (he_so * pn) tai cac vi tri tan so trung binh.
    Neu tong > 0 -> bit = 1, nguoc lai -> bit = 0.
    """
    corr = 0.0
    for k in range(len(pn)):
        r, c = MID_FREQ[k]
        # TODO: Cong dct_block[r, c] * pn[k] vao corr
        pass  
    return 1 if corr > 0 else 0


# PHAN 3: IMAGE REGISTRATION (Hieu chinh hinh hoc)
# Khi anh bi xoay/dich chuyen, thu nhieu goc/vi tri de tim lai goc dung

def try_header(img, alpha, repeat):
    """Thu trich xuat header tu anh, tra ve (hop_le, do_dai)"""
    h, w = (img.shape[0]//8)*8, (img.shape[1]//8)*8
    raw = []
    count = 0
    needed = 32 * repeat
    for i in range(0, h, 8):
        for j in range(0, w, 8):
            if count >= needed:
                break
            block = dctn(img[i:i+8, j:j+8].astype(np.float64), norm='ortho')
            pn = make_pn(12345 + (i//8)*(w//8) + j//8)
            raw.append(ss_extract_block(block, pn))
            count += 1
    dec = repetition_decode(raw)
    if len(dec) < 32:
        return False, -1
    length = int(''.join(str(b) for b in dec[:32]), 2)
    return (0 < length < 5000), length

def register_image(img, alpha):
    """Thu hieu chinh anh bi tan cong hinh hoc.
    Buoc 1: Thu truc tiep (khong hieu chinh)
    Buoc 2: Thu xoay nguoc cac goc tu -15 den +15 do
    Buoc 3: Thu dich chuyen nguoc tu -15 den +15 pixel
    """
    h, w = img.shape[:2]

    # Thu truc tiep
    ok, length = try_header(img, alpha, REPEAT)
    if ok:
        print("  -> Khong can hieu chinh (header ok, len=%d)" % length)
        return img

    print("  -> Header hong, thu hieu chinh xoay...")
    # TODO: Vong lap thu cac goc tu -15 den +15 (buoc 0.5)
    # Voi moi goc:
    #   1. Tao ma tran xoay: M = cv2.getRotationMatrix2D((w//2,h//2), -goc, 1.0)
    #   2. Xoay nguoc anh:   fixed = cv2.warpAffine(img, M, (w, h), borderMode=cv2.BORDER_REFLECT)
    #   3. Kiem tra header:   ok, length = try_header(fixed, alpha, REPEAT)
    #   4. Neu ok -> return fixed
    #
    # Goi y: for angle in np.arange(-15, 15.5, 0.5):
    pass  

    print("  -> Thu hieu chinh dich chuyen...")
    # TODO: Vong lap thu dich chuyen tu -15 den +15 pixel (ca dx va dy)
    # Voi moi (dx, dy):
    #   1. Tao ma tran dich: M = np.float32([[1,0,-dx],[0,1,-dy]])
    #   2. Dich nguoc anh:   fixed = cv2.warpAffine(img, M, (w, h), borderMode=cv2.BORDER_REFLECT)
    #   3. Kiem tra header:   ok, length = try_header(fixed, alpha, REPEAT)
    #   4. Neu ok -> return fixed
    pass  

    print("  -> Khong hieu chinh duoc!")
    return img


# === HAM NHUNG VA TRICH XUAT CHINH ===
def text_to_bits(text):
    bits = []
    for ch in text:
        for b in format(ord(ch), '08b'):
            bits.append(int(b))
    return bits

def bits_to_text(bits):
    chars = []
    for i in range(0, len(bits), 8):
        byte = bits[i:i+8]
        if len(byte) < 8:
            break
        val = int(''.join(str(b) for b in byte), 2)
        if val == 0:
            break
        if 0 < val < 128:
            chars.append(chr(val))
    return ''.join(chars)

def defense_embed(cover_path, message, output_path, alpha=15):
    img = np.array(Image.open(cover_path).convert('L'), dtype=np.float64)
    h, w = (img.shape[0]//8)*8, (img.shape[1]//8)*8
    img = img[:h, :w]
    stego = img.copy()

    # Chuan bi bits + ma sua loi
    header = [int(b) for b in format(len(message), '032b')]
    msg_bits = text_to_bits(message + '\x00')
    encoded = repetition_encode(header + msg_bits)

    total = (h//8) * (w//8)
    if len(encoded) > total:
        print("LOI: Thong diep qua dai! Can %d khoi, chi co %d" % (len(encoded), total))
        return
    print("Nhung %d bit (sau ma hoa %d bit) vao %d khoi" % (len(header+msg_bits), len(encoded), total))

    idx = 0
    for i in range(0, h, 8):
        for j in range(0, w, 8):
            if idx >= len(encoded):
                break
            block = dctn(stego[i:i+8, j:j+8], norm='ortho')
            pn = make_pn(12345 + (i//8)*(w//8) + j//8)
            block = ss_embed_block(block, encoded[idx], pn, alpha)
            stego[i:i+8, j:j+8] = idctn(block, norm='ortho')
            idx += 1

    stego = np.clip(stego, 0, 255).astype(np.uint8)
    Image.fromarray(stego).save(output_path)
    mse = np.mean((img - stego.astype(np.float64))**2)
    psnr = 10*np.log10(255**2/mse) if mse > 0 else 999
    print("Luu: %s | PSNR=%.2f dB" % (output_path, psnr))

def defense_extract(stego_path, alpha=15):
    img = np.array(Image.open(stego_path).convert('L'), dtype=np.float64)
    h, w = (img.shape[0]//8)*8, (img.shape[1]//8)*8
    img = img[:h, :w]

    # Hieu chinh hinh hoc
    print("Buoc 1: Image Registration")
    img = register_image(img, alpha).astype(np.float64)
    img = img[:(img.shape[0]//8)*8, :(img.shape[1]//8)*8]
    h, w = img.shape

    # Trich xuat spread spectrum
    print("Buoc 2: Spread Spectrum Extract")
    raw = []
    for i in range(0, h, 8):
        for j in range(0, w, 8):
            block = dctn(img[i:i+8, j:j+8], norm='ortho')
            pn = make_pn(12345 + (i//8)*(w//8) + j//8)
            raw.append(ss_extract_block(block, pn))

    # Giai ma sua loi
    print("Buoc 3: Error Correction Decode")
    decoded = repetition_decode(raw)
    if len(decoded) < 32:
        print("THAT BAI: khong du bit")
        return None
    length = int(''.join(str(b) for b in decoded[:32]), 2)
    if 0 < length < 5000:
        msg = bits_to_text(decoded[32:32+(length+1)*8])
        print("Ket qua: \"%s\"" % msg)
        return msg
    else:
        print("THAT BAI: header hong (len=%d)" % length)
        return None

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Nhung: python3 defense.py embed <anh> <msg> <output> [alpha]")
        print("Trich: python3 defense.py extract <anh_stego> [alpha]")
    elif sys.argv[1] == 'embed':
        a = float(sys.argv[5]) if len(sys.argv) > 5 else 15
        defense_embed(sys.argv[2], sys.argv[3], sys.argv[4], a)
    elif sys.argv[1] == 'extract':
        a = float(sys.argv[3]) if len(sys.argv) > 3 else 15
        defense_extract(sys.argv[2], a)
