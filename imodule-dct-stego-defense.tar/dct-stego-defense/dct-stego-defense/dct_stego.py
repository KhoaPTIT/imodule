#!/usr/bin/env python3
# dct_stego.py - Thu vien nhung/trich xuat DCT co ban (CUNG CAP SAN)
import numpy as np
from scipy.fft import dctn, idctn
from PIL import Image

def text_to_bits(text):
    bits = []
    for ch in text:
        for b in format(ord(ch), '08b'):
            bits.append(int(b))
    return bits

def bits_to_text(bits):
    chars = []
    for i in range(0, len(bits), 8):
        byte = bits[i:i+8]
        if len(byte) < 8:
            break
        val = int(''.join(str(b) for b in byte), 2)
        if val == 0:
            break
        chars.append(chr(val))
    return ''.join(chars)

def embed(cover_path, message, output_path, alpha=25):
    """Nhung thong diep vao anh bang DCT. Tra ve PSNR."""
    img = np.array(Image.open(cover_path).convert('L'), dtype=np.float64)
    h, w = (img.shape[0]//8)*8, (img.shape[1]//8)*8
    img = img[:h, :w]
    stego = img.copy()

    bits = text_to_bits(message + '\x00')
    header = [int(b) for b in format(len(message), '032b')]
    all_bits = header + bits

    idx = 0
    for i in range(0, h, 8):
        for j in range(0, w, 8):
            if idx >= len(all_bits):
                break
            block = dctn(stego[i:i+8, j:j+8], norm='ortho')
            q = alpha * round(block[4,3] / alpha)
            block[4,3] = q + alpha/4 if all_bits[idx] == 1 else q - alpha/4
            stego[i:i+8, j:j+8] = idctn(block, norm='ortho')
            idx += 1

    stego = np.clip(stego, 0, 255).astype(np.uint8)
    Image.fromarray(stego).save(output_path)
    mse = np.mean((img - stego.astype(np.float64))**2)
    psnr = 10*np.log10(255**2/mse) if mse > 0 else 999
    print("Nhung thanh cong: %s | PSNR=%.2f dB | %d bits" % (output_path, psnr, idx))
    return psnr

def extract(stego_path, alpha=25):
    """Trich xuat thong diep tu anh stego."""
    img = np.array(Image.open(stego_path).convert('L'), dtype=np.float64)
    h, w = (img.shape[0]//8)*8, (img.shape[1]//8)*8
    img = img[:h, :w]

    bits = []
    for i in range(0, h, 8):
        for j in range(0, w, 8):
            block = dctn(img[i:i+8, j:j+8], norm='ortho')
            q = alpha * round(block[4,3] / alpha)
            bits.append(1 if block[4,3] - q >= 0 else 0)

    length = int(''.join(str(b) for b in bits[:32]), 2)
    if 0 < length < 5000:
        msg = bits_to_text(bits[32:32+(length+1)*8])
        print("Trich xuat: \"%s\"" % msg)
        return msg
    else:
        print("THAT BAI - khong doc duoc header (len=%d)" % length)
        return None

if __name__ == "__main__":
    import sys
    if len(sys.argv) < 3:
        print("Nhung: python3 dct_stego.py embed <anh> <msg> <output> [alpha]")
        print("Trich: python3 dct_stego.py extract <anh_stego> [alpha]")
    elif sys.argv[1] == 'embed':
        a = float(sys.argv[5]) if len(sys.argv) > 5 else 25
        embed(sys.argv[2], sys.argv[3], sys.argv[4], a)
    elif sys.argv[1] == 'extract':
        a = float(sys.argv[3]) if len(sys.argv) > 3 else 25
        extract(sys.argv[2], a)
