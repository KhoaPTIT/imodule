#!/usr/bin/env python3
# attack.py - Tan cong hinh hoc bang OpenCV
import numpy as np
import cv2
import sys

if len(sys.argv) < 4:
    print("Su dung:")
    print("  python3 attack.py rotate  <anh> <goc>       <output>")
    print("  python3 attack.py shift   <anh> <pixels>    <output>")
    print("  python3 attack.py scale   <anh> <ty_le>     <output>")
    print("  python3 attack.py crop    <anh> <phan_tram> <output>")
    print("  python3 attack.py combo   <anh>             <output>")
    sys.exit(1)

cmd = sys.argv[1]
img = cv2.imread(sys.argv[2], cv2.IMREAD_GRAYSCALE)
h, w = img.shape

if cmd == 'rotate':
    angle = float(sys.argv[3])
    out = sys.argv[4]
    M = cv2.getRotationMatrix2D((w//2, h//2), angle, 1.0)
    result = cv2.warpAffine(img, M, (w, h), borderMode=cv2.BORDER_REFLECT)
    cv2.imwrite(out, result)
    print("Xoay %.1f do -> %s" % (angle, out))

elif cmd == 'shift':
    px = int(sys.argv[3])
    out = sys.argv[4]
    M = np.float32([[1, 0, px], [0, 1, px]])
    result = cv2.warpAffine(img, M, (w, h), borderMode=cv2.BORDER_REFLECT)
    cv2.imwrite(out, result)
    print("Dich chuyen %d px -> %s" % (px, out))

elif cmd == 'scale':
    s = float(sys.argv[3])
    out = sys.argv[4]
    small = cv2.resize(img, (int(w*s), int(h*s)))
    result = cv2.resize(small, (w, h))
    cv2.imwrite(out, result)
    print("Co gian %.2fx -> %s" % (s, out))

elif cmd == 'crop':
    pct = int(sys.argv[3])
    out = sys.argv[4]
    c = int(min(h,w) * pct / 100)
    cropped = img[c:h-c, c:w-c]
    result = cv2.resize(cropped, (w, h))
    cv2.imwrite(out, result)
    print("Cat xen %d%% -> %s" % (pct, out))

elif cmd == 'combo':
    out = sys.argv[3]
    M = cv2.getRotationMatrix2D((w//2, h//2), 3, 1.0)
    result = cv2.warpAffine(img, M, (w, h), borderMode=cv2.BORDER_REFLECT)
    small = cv2.resize(result, (int(w*0.95), int(h*0.95)))
    result = cv2.resize(small, (w, h))
    cv2.imwrite(out, result)
    print("To hop (xoay 3 + scale 0.95) -> %s" % out)
